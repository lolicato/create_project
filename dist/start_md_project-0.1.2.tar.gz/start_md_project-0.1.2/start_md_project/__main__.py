# start_md_project/__main__.py

def main():
    print("✅ start_md_project is working!")