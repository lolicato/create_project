# create_project


How to use:

```
python  create-project.py project_folder_name
```
